#!/bin/bash
# prints itself backwards
#
# "IS THIS CHEATING??????"
# NO, BECAUSE IT WORKS
tail -r $0
